# Copyright (c) Alibaba, Inc. and its affiliates.

from .speech_synthesizer import SpeechSynthesizer

__all__ = [SpeechSynthesizer]
